'use strict';
const d=document.getElementById('date9');if(d){const n=new Date();d.textContent=n.toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).toUpperCase();}
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const delay=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),delay);obs.unobserve(e.target);}),{threshold:.12});
document.querySelectorAll('.reveal9').forEach(el=>obs.observe(el));
const form=document.getElementById('form9'),suc=document.getElementById('suc9');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f9n','f9b','f9e','f9i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='FILL ALL FIELDS →';setTimeout(()=>b.textContent='SUBMIT REQUEST →',1600);return;}
const b=form.querySelector('button');b.textContent='SUBMITTING…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
