'use strict';
// Waveform
const wv=document.getElementById('wave7');
if(wv){for(let i=0;i<36;i++){const b=document.createElement('div');const h=Math.random()*70+15;b.style.cssText=`width:3px;border-radius:2px;background:linear-gradient(to top,#00C853,#69F0AE);animation:wv7 ${(Math.random()*.6+.4).toFixed(2)}s ease-in-out ${(Math.random()*.5).toFixed(2)}s infinite alternate;height:${h}%`;wv.appendChild(b);}
const st=document.createElement('style');st.textContent='@keyframes wv7{from{transform:scaleY(.3)}to{transform:scaleY(1)}}';document.head.appendChild(st);}

const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal7').forEach(el=>obs.observe(el));

const form=document.getElementById('form7'),suc=document.getElementById('suc7');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f7n','f7b','f7e','f7i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='Please fill all fields';setTimeout(()=>b.textContent='Join the Waitlist →',1600);return;}
const b=form.querySelector('button');b.textContent='Joining…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
