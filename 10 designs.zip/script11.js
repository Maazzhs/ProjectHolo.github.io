'use strict';
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal11').forEach(el=>obs.observe(el));
const form=document.getElementById('form11'),suc=document.getElementById('suc11');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f11n','f11b','f11e','f11i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='⚠️ Fill all fields!';setTimeout(()=>b.textContent='Join the Waitlist 🚀',1600);return;}
const b=form.querySelector('button');b.textContent='Joining… ⏳';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
