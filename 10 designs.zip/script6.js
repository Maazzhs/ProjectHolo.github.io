'use strict';
const bootLines=['HOLOCOMS BIOS v0.7.2','Copyright (C) 2025 HoloComs Ltd. All Rights Reserved.','','Detecting CPU... Intel Core i9 [OK]','Checking RAM... 65536KB [OK]','Initialising NLP Engine... [OK]','Loading Voice Processor... [OK]','Mounting Knowledge Base... [OK]','Checking Calendar API... [WARNING: 72% complete]','Loading Sentiment Module... [WARNING: 38% complete]','CRM Connector... [NOT FOUND - PLANNED]','','Starting HOLOCOMS.EXE...',''];
const bootEl=document.getElementById('boot-text6'),prog=document.getElementById('boot-prog6'),main=document.getElementById('main6'),bootScr=document.getElementById('boot6');
let li=0,ci=0,txt='';
function bootType(){if(li>=bootLines.length){prog.style.width='100%';setTimeout(()=>{bootScr.style.display='none';main.style.display='block';startMain();},400);return;}
const line=bootLines[li];if(ci<=line.length){txt+=line[ci]||'';bootEl.textContent=txt+(ci<line.length?'█':'');ci++;setTimeout(bootType,ci<=line.length?18:0);}else{txt+='\n';li++;ci=0;prog.style.width=(li/bootLines.length*100)+'%';setTimeout(bootType,li<bootLines.length?80:200);}}
setTimeout(bootType,300);

function startMain(){
// Clock
const t=document.getElementById('sb-time6');function clk(){const n=new Date(),p=v=>String(v).padStart(2,'0');t.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());}clk();setInterval(clk,1000);
// Typewriter
const tw=document.getElementById('typewrite6');const phrases=['INTELLIGENT. ADAPTIVE. ALWAYS ON.','NO SCRIPTS. NO HOLD MUSIC. NO LIMITS.','YOUR FRONT DESK. REINVENTED.'];let pi=0,chi=0,del=false;
function typ(){const cur=phrases[pi];const spd=del?30:60;if(!del&&chi<=cur.length){tw.textContent=cur.slice(0,chi++);}else if(del&&chi>=0){tw.textContent=cur.slice(0,chi--);}
if(!del&&chi>cur.length){del=true;setTimeout(typ,1600);return;}if(del&&chi<0){del=false;pi=(pi+1)%phrases.length;setTimeout(typ,300);return;}
setTimeout(typ,spd);}
setTimeout(typ,500);
// Reveals
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal6').forEach(el=>obs.observe(el));
// Form
const form=document.getElementById('form6'),suc=document.getElementById('suc6');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f6n','f6b','f6e','f6i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='> ERROR: FILL ALL FIELDS';setTimeout(()=>b.textContent='> SUBMIT REGISTRATION [ENTER]',1600);return;}
const b=form.querySelector('button');b.textContent='> TRANSMITTING...';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},1000);});}
