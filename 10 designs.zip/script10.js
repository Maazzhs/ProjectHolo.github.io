'use strict';
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal10').forEach(el=>obs.observe(el));
const form=document.getElementById('form10'),suc=document.getElementById('suc10');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f10n','f10b','f10e','f10i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='Please fill all fields';setTimeout(()=>b.textContent='Join the waitlist',1600);return;}
const b=form.querySelector('button');b.textContent='Joining…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
