'use strict';
// Particle canvas
const c=document.getElementById('c12'),ctx=c.getContext('2d');
function rsz(){c.width=innerWidth;c.height=innerHeight;}rsz();window.addEventListener('resize',rsz);
const pts=Array.from({length:60},()=>({x:Math.random()*innerWidth,y:Math.random()*innerHeight,vx:(Math.random()-.5)*.2,vy:(Math.random()-.5)*.2,r:Math.random()*1.5+.3,a:Math.random()*.5+.1}));
function draw(){ctx.clearRect(0,0,c.width,c.height);pts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>c.width)p.vx*=-1;if(p.y<0||p.y>c.height)p.vy*=-1;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(92,184,122,${p.a})`;ctx.fill();});requestAnimationFrame(draw);}
draw();

// Waveform
const wv=document.getElementById('wave12');
if(wv){for(let i=0;i<40;i++){const b=document.createElement('div');const h=Math.random()*60+10;b.style.cssText=`width:4px;border-radius:2px;background:linear-gradient(to top,rgba(61,107,69,.6),rgba(92,184,122,.9));flex:1;animation:wv12 ${(Math.random()*.7+.4).toFixed(2)}s ease-in-out ${(Math.random()*.5).toFixed(2)}s infinite alternate;height:${h}%`;wv.appendChild(b);}
const st=document.createElement('style');st.textContent='.hc12-wave{display:flex;align-items:center;gap:2px}@keyframes wv12{from{transform:scaleY(.2)}to{transform:scaleY(1)}}';document.head.appendChild(st);}

// Reveals
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal12').forEach(el=>obs.observe(el));

// Form
const form=document.getElementById('form12'),suc=document.getElementById('suc12');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f12n','f12b','f12e','f12i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='Fill all fields';setTimeout(()=>b.textContent='Request Early Access',1600);return;}
const b=form.querySelector('button');b.textContent='Sending…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
