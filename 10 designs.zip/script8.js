'use strict';
const c=document.getElementById('stars8'),ctx=c.getContext('2d');
function rsz(){c.width=innerWidth;c.height=innerHeight;}rsz();window.addEventListener('resize',rsz);
const stars=Array.from({length:160},()=>({x:Math.random()*innerWidth,y:Math.random()*innerHeight,r:Math.random()*1.2+.2,a:Math.random()}));
function drawStars(){ctx.clearRect(0,0,c.width,c.height);stars.forEach(s=>{ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fillStyle=`rgba(200,230,255,${s.a*.4})`;ctx.fill();});requestAnimationFrame(drawStars);}
drawStars();

const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal8').forEach(el=>obs.observe(el));

const form=document.getElementById('form8'),suc=document.getElementById('suc8');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f8n','f8b','f8e','f8i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='Please fill all fields';setTimeout(()=>b.textContent='Request Early Access',1600);return;}
const b=form.querySelector('button');b.textContent='Sending…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
