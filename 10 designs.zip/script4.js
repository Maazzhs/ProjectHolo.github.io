'use strict';
// Canvas grid
const c=document.getElementById('c4'),ctx=c.getContext('2d');
function rsz(){c.width=window.innerWidth;c.height=window.innerHeight;}
rsz();window.addEventListener('resize',rsz);
function draw(){ctx.clearRect(0,0,c.width,c.height);ctx.strokeStyle='rgba(123,47,190,0.12)';ctx.lineWidth=.5;
for(let x=0;x<c.width;x+=60){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,c.height);ctx.stroke();}
for(let y=0;y<c.height;y+=60){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(c.width,y);ctx.stroke();}}
draw();window.addEventListener('resize',draw);

// Custom cursor
const cc=document.createElement('canvas');cc.style.cssText='position:fixed;inset:0;z-index:9999;pointer-events:none;width:100%;height:100%';
cc.width=window.innerWidth;cc.height=window.innerHeight;
document.body.appendChild(cc);const cx=cc.getContext('2d');
let mx=0,my=0;document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;});
window.addEventListener('resize',()=>{cc.width=window.innerWidth;cc.height=window.innerHeight;});
(function loop(){cc.clearRect(0,0,cc.width,cc.height);cx.strokeStyle='rgba(0,245,255,0.8)';cx.lineWidth=1;
cx.beginPath();cx.moveTo(mx-12,my);cx.lineTo(mx+12,my);cx.moveTo(mx,my-12);cx.lineTo(mx,my+12);cx.stroke();
cx.beginPath();cx.arc(mx,my,4,0,Math.PI*2);cx.fillStyle='rgba(255,45,120,0.9)';cx.fill();requestAnimationFrame(loop);})();

// HUD ring
const r4=document.getElementById('r4'),r42=document.getElementById('r42'),hpct=document.getElementById('hpct4');
const obs=new IntersectionObserver(es=>{if(!es[0].isIntersecting)return;
let n=0;const iv=setInterval(()=>{n+=1;if(n>68){clearInterval(iv);return;}hpct.textContent=n+'%';
r4.style.strokeDashoffset=(628-(628*.68*n/68));r42.style.strokeDashoffset=(471-(471*.45*n/68));},30);
obs.disconnect();},{threshold:.3});
const hud=document.querySelector('.hud-ring');if(hud)obs.observe(hud);

// Reveal
const robs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);robs.unobserve(e.target);}),{threshold:.1});
document.querySelectorAll('.reveal4').forEach(el=>robs.observe(el));

// Glitch title
const h1=document.getElementById('h4glitch');
function glitch(){if(!h1)return;const orig='HOLOCOMS',chars='!@#$%◆▓░01XZ';let i=0;
const iv=setInterval(()=>{h1.textContent=orig.split('').map((c,idx)=>idx<i?c:chars[Math.floor(Math.random()*chars.length)]).join('');
i+=.6;if(i>=orig.length){h1.textContent=orig;clearInterval(iv);}},45);}
setTimeout(glitch,600);setInterval(glitch,8000);
if(h1)h1.addEventListener('mouseenter',glitch);

// Form
const form=document.getElementById('form4'),suc=document.getElementById('suc4');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f4n','f4b','f4e','f4i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='[ FILL ALL FIELDS ]';setTimeout(()=>b.textContent='[ TRANSMIT REQUEST ]',1600);return;}
const b=form.querySelector('button');b.textContent='[ TRANSMITTING... ]';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},1000);});
