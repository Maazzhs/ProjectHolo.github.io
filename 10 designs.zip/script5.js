'use strict';
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.15});
document.querySelectorAll('.reveal5').forEach(el=>obs.observe(el));
const form=document.getElementById('form5'),suc=document.getElementById('suc5');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=['f5n','f5b','f5e','f5i'].map(id=>document.getElementById(id));
if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');const orig=b.textContent;b.textContent='FILL ALL FIELDS →';setTimeout(()=>b.textContent=orig,1600);return;}
const b=form.querySelector('button');b.textContent='SENDING…';
setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
