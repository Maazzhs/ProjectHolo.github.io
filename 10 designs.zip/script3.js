'use strict';
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const d=+(e.target.dataset.d||0);setTimeout(()=>e.target.classList.add('visible'),d);obs.unobserve(e.target);}),{threshold:.12});
document.querySelectorAll('.reveal,[data-d]').forEach(el=>obs.observe(el));
const form=document.getElementById('form3'),suc=document.getElementById('suc3');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=[document.getElementById('f3n'),document.getElementById('f3b'),document.getElementById('f3e'),document.getElementById('f3i')];if(v.some(i=>!i.value.trim())){const b=form.querySelector('button');b.textContent='Please fill all fields';setTimeout(()=>b.textContent='Request Access',1600);return;}const b=form.querySelector('button');b.textContent='Sending…';setTimeout(()=>{form.style.display='none';suc.classList.add('show');},900);});
