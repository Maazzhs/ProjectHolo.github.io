'use strict';
// Call wave
const cw = document.getElementById('cw14');
if (cw) {
  for (let i = 0; i < 48; i++) {
    const b = document.createElement('div');
    const h = Math.random() * 65 + 12;
    b.style.cssText = `flex:1;border-radius:2px;background:rgba(45,184,84,0.8);
      animation:cwv14 ${(Math.random()*0.6+0.35).toFixed(2)}s ease-in-out ${(Math.random()*0.4).toFixed(2)}s infinite alternate;
      height:${h}%`;
    cw.appendChild(b);
  }
  const s = document.createElement('style');
  s.textContent = '.call14-wave{display:flex;align-items:center;gap:2px}@keyframes cwv14{from{transform:scaleY(0.2)}to{transform:scaleY(1)}}';
  document.head.appendChild(s);
}

// Call timer
let secs = 42;
const ct = document.getElementById('calltimer14');
setInterval(() => {
  if (!ct) return; secs++;
  const m = Math.floor(secs / 60), s = secs % 60;
  ct.textContent = String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}, 1000);

// Terminal
const term = document.getElementById('term14');
const tlines = [
  {t:'> holo-engine v0.7.2 starting up…', c:'tdim'},
  {t:'✓ NLP pipeline loaded', c:'tok'},
  {t:'✓ Voice processor active', c:'tok'},
  {t:'⚠ Calendar API — 72% complete', c:'twarn'},
  {t:'✓ Knowledge base: 841 entries', c:'tok'},
  {t:'> next: caller memory module', c:'tdim'},
];
const termObs = new IntersectionObserver(([e]) => {
  if (!e.isIntersecting) return;
  tlines.forEach(({t, c}, i) => {
    setTimeout(() => {
      if (!term) return;
      const d = document.createElement('div');
      d.className = c; d.textContent = t;
      term.appendChild(d);
    }, i * 300);
  });
  termObs.disconnect();
}, { threshold: 0.3 });
if (term) termObs.observe(term);

// Reveal
const obs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const d = +(e.target.dataset.d || 0);
  setTimeout(() => e.target.classList.add('visible'), d);
  obs.unobserve(e.target);
}), { threshold: 0.1 });
document.querySelectorAll('.reveal14').forEach(el => obs.observe(el));

// Counter
const cntEls = document.querySelectorAll('.counter14');
const cntObs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const target = +e.target.dataset.target;
  let n = 0; const start = performance.now();
  function step(now) { const p = Math.min((now - start) / 1800, 1), ease = 1 - Math.pow(1-p,3);
    e.target.textContent = Math.round(ease * target); if (p < 1) requestAnimationFrame(step); }
  requestAnimationFrame(step); cntObs.unobserve(e.target);
}), { threshold: 0.5 });
cntEls.forEach(el => cntObs.observe(el));

// Form
const form = document.getElementById('form14'), suc = document.getElementById('suc14');
if (form) form.addEventListener('submit', e => {
  e.preventDefault();
  const v = ['f14n','f14b','f14e','f14i'].map(id => document.getElementById(id));
  if (v.some(i => !i.value.trim())) {
    const b = form.querySelector('button'); b.textContent = 'Please fill all fields';
    setTimeout(() => b.textContent = 'Request Early Access →', 1600); return;
  }
  const b = form.querySelector('button'); b.textContent = 'Joining…';
  setTimeout(() => { form.style.display = 'none'; suc.classList.add('show'); }, 900);
});
