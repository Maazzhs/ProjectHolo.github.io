'use strict';
// Particle canvas — gold motes
const cv = document.getElementById('c17'), cx = cv.getContext('2d');
function rsz() { cv.width = innerWidth; cv.height = innerHeight; } rsz();
window.addEventListener('resize', rsz);
const motes = Array.from({length:60}, () => ({
  x: Math.random()*innerWidth, y: Math.random()*innerHeight,
  vx: (Math.random()-.5)*0.15, vy: -(Math.random()*0.2+0.05),
  r: Math.random()*1.2+0.2,
  a: Math.random()*0.3+0.05,
  life: Math.random(),
}));
(function loop() {
  cx.clearRect(0,0,cv.width,cv.height);
  motes.forEach((m,i) => {
    m.x += m.vx; m.y += m.vy; m.life += 0.003;
    if (m.y < -10 || m.life > 1) {
      motes[i] = {x:Math.random()*innerWidth, y:innerHeight+10, vx:(Math.random()-.5)*0.15, vy:-(Math.random()*0.2+0.05), r:Math.random()*1.2+0.2, a:Math.random()*0.3+0.05, life:0};
    }
    const alpha = Math.sin(Math.PI * m.life) * m.a;
    cx.beginPath(); cx.arc(m.x, m.y, m.r, 0, Math.PI*2);
    cx.fillStyle = `rgba(201,168,76,${alpha})`; cx.fill();
  });
  requestAnimationFrame(loop);
})();

// Reveals
const obs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const d = +(e.target.dataset.d || 0);
  setTimeout(() => e.target.classList.add('visible'), d);
  obs.unobserve(e.target);
}), { threshold: 0.1 });
document.querySelectorAll('.reveal17').forEach(el => obs.observe(el));

// Form
const form = document.getElementById('form17'), suc = document.getElementById('suc17');
if (form) form.addEventListener('submit', e => {
  e.preventDefault();
  const v = ['f17n','f17b','f17e','f17i'].map(id => document.getElementById(id));
  if (v.some(i => !i.value.trim())) {
    const b = form.querySelector('button'); b.textContent = '◇ FILL ALL FIELDS';
    setTimeout(() => b.textContent = '◈ SUBMIT REQUEST', 1600); return;
  }
  const b = form.querySelector('button'); b.textContent = '◈ TRANSMITTING…';
  setTimeout(() => { form.style.display = 'none'; suc.classList.add('show'); }, 1000);
});
