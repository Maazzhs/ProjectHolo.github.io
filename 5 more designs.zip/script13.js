'use strict';
// Cursor
document.addEventListener('mousemove', e => {
  document.documentElement.style.setProperty('--cx', e.clientX + 'px');
  document.documentElement.style.setProperty('--cy', e.clientY + 'px');
});

// Nav clock
const nc = document.getElementById('nc13');
function tick() { if (!nc) return; const n = new Date(), p = v => String(v).padStart(2,'0');
  nc.textContent = `${p(n.getHours())}:${p(n.getMinutes())}:${p(n.getSeconds())} — ALPHA BUILD #041`; }
tick(); setInterval(tick, 1000);

// BG starfield
const bg = document.getElementById('c13'), bc = bg.getContext('2d');
function rsz() { bg.width = innerWidth; bg.height = innerHeight; } rsz();
window.addEventListener('resize', rsz);
const stars = Array.from({length:120}, () => ({x:Math.random()*innerWidth, y:Math.random()*innerHeight, r:Math.random()*0.8+0.2, a:Math.random()*0.4+0.05}));
function drawBG() { bc.clearRect(0,0,bg.width,bg.height);
  stars.forEach(s => { bc.beginPath(); bc.arc(s.x,s.y,s.r,0,Math.PI*2); bc.fillStyle=`rgba(248,245,240,${s.a})`; bc.fill(); });
  requestAnimationFrame(drawBG); }
drawBG();

// Morphing orb
const oc = document.getElementById('orb13');
if (oc) {
  const ctx = oc.getContext('2d');
  let t = 0;
  function drawOrb() {
    ctx.clearRect(0, 0, 500, 500);
    const cx = 250, cy = 250;
    t += 0.008;
    // Draw glow
    const grd = ctx.createRadialGradient(cx, cy, 20, cx, cy, 180);
    grd.addColorStop(0, 'rgba(29,185,84,0.18)');
    grd.addColorStop(0.5, 'rgba(29,185,84,0.06)');
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd; ctx.fillRect(0,0,500,500);
    // Draw morphing blob
    ctx.save();
    ctx.translate(cx, cy);
    ctx.beginPath();
    const pts2 = 64;
    for (let i = 0; i <= pts2; i++) {
      const a = (i / pts2) * Math.PI * 2;
      const noise = Math.sin(a * 3 + t) * 14 + Math.sin(a * 7 - t * 1.3) * 8 + Math.cos(a * 5 + t * 0.7) * 6;
      const r = 120 + noise;
      const x = Math.cos(a) * r, y = Math.sin(a) * r;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.closePath();
    const bGrd = ctx.createRadialGradient(0, 0, 0, 0, 0, 140);
    bGrd.addColorStop(0, 'rgba(100,220,140,0.35)');
    bGrd.addColorStop(0.4, 'rgba(29,185,84,0.2)');
    bGrd.addColorStop(0.8, 'rgba(18,110,50,0.1)');
    bGrd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = bGrd; ctx.fill();
    ctx.strokeStyle = 'rgba(29,185,84,0.5)'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.restore();
    // Inner dot
    ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI*2);
    ctx.fillStyle = 'rgba(29,185,84,0.8)'; ctx.fill();
    requestAnimationFrame(drawOrb);
  }
  drawOrb();
}

// Reveals
const obs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const d = +(e.target.dataset.d || 0);
  setTimeout(() => e.target.classList.add('visible'), d);
  obs.unobserve(e.target);
}), { threshold: 0.1 });
document.querySelectorAll('.reveal13').forEach(el => obs.observe(el));

// Form
const form = document.getElementById('form13'), suc = document.getElementById('suc13');
if (form) form.addEventListener('submit', e => {
  e.preventDefault();
  const v = ['f13n','f13b','f13e','f13i'].map(id => document.getElementById(id));
  if (v.some(i => !i.value.trim())) {
    const b = form.querySelector('button'); b.textContent = 'Fill all fields';
    setTimeout(() => b.textContent = 'Request Access', 1600); return;
  }
  const b = form.querySelector('button'); b.textContent = 'Sending…';
  setTimeout(() => { form.style.display = 'none'; suc.classList.add('show'); }, 900);
});
