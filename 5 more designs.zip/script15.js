'use strict';
// Animated mesh gradient canvas
const canvas = document.getElementById('mesh15'), ctx = canvas.getContext('2d');
function rsz() { canvas.width = innerWidth; canvas.height = innerHeight; }
rsz(); window.addEventListener('resize', rsz);
let t = 0;
const pts = [
  { x: 0.2, y: 0.3, vx: 0.0003, vy: 0.0002, c: [14, 100, 60] },
  { x: 0.8, y: 0.2, vx: -0.0002, vy: 0.0003, c: [8, 60, 30] },
  { x: 0.5, y: 0.8, vx: 0.0004, vy: -0.0002, c: [30, 80, 50] },
  { x: 0.1, y: 0.7, vx: 0.0002, vy: 0.0004, c: [5, 40, 20] },
  { x: 0.9, y: 0.6, vx: -0.0003, vy: -0.0003, c: [20, 70, 40] },
];
function drawMesh() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  pts.forEach(p => {
    p.x += p.vx; p.y += p.vy;
    if (p.x < 0 || p.x > 1) p.vx *= -1;
    if (p.y < 0 || p.y > 1) p.vy *= -1;
    const grd = ctx.createRadialGradient(p.x * canvas.width, p.y * canvas.height, 0, p.x * canvas.width, p.y * canvas.height, Math.min(canvas.width, canvas.height) * 0.55);
    grd.addColorStop(0, `rgba(${p.c[0]},${p.c[1]},${p.c[2]},0.55)`);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd; ctx.fillRect(0, 0, canvas.width, canvas.height);
  });
  // Green accent blob
  const ga = ctx.createRadialGradient(canvas.width * 0.6, canvas.height * 0.4, 0, canvas.width * 0.6, canvas.height * 0.4, canvas.width * 0.2);
  ga.addColorStop(0, 'rgba(61,255,143,0.06)'); ga.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = ga; ctx.fillRect(0, 0, canvas.width, canvas.height);
  requestAnimationFrame(drawMesh);
}
drawMesh();

// Reveals
const obs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const d = +(e.target.dataset.d || 0);
  setTimeout(() => e.target.classList.add('visible'), d);
  obs.unobserve(e.target);
}), { threshold: 0.1 });
document.querySelectorAll('.reveal15').forEach(el => obs.observe(el));

// Form
const form = document.getElementById('form15'), suc = document.getElementById('suc15');
if (form) form.addEventListener('submit', e => {
  e.preventDefault();
  const v = ['f15n','f15b','f15e','f15i'].map(id => document.getElementById(id));
  if (v.some(i => !i.value.trim())) {
    const b = form.querySelector('button'); b.textContent = 'Fill all fields';
    setTimeout(() => b.textContent = 'Request Early Access', 1600); return;
  }
  const b = form.querySelector('button'); b.textContent = 'Sending…';
  setTimeout(() => { form.style.display = 'none'; suc.classList.add('show'); }, 900);
});
