'use strict';
// Cursor
document.addEventListener('mousemove', e => {
  document.documentElement.style.setProperty('--cx', e.clientX + 'px');
  document.documentElement.style.setProperty('--cy', e.clientY + 'px');
});

// Clock
const nc = document.getElementById('nclock16');
function tick() { if (!nc) return; const n = new Date(), p = v => String(v).padStart(2,'0');
  nc.textContent = `${p(n.getHours())}:${p(n.getMinutes())}:${p(n.getSeconds())}`; }
tick(); setInterval(tick, 1000);

// Subtle particle canvas
const cv = document.getElementById('c16'), cx = cv.getContext('2d');
function rsz() { cv.width = innerWidth; cv.height = innerHeight; } rsz();
window.addEventListener('resize', rsz);
const stars = Array.from({length:80}, () => ({
  x: Math.random()*innerWidth, y: Math.random()*innerHeight,
  r: Math.random()*0.7+0.2, a: Math.random()*0.25+0.03
}));
(function loop() { cx.clearRect(0,0,cv.width,cv.height);
  stars.forEach(s => { cx.beginPath(); cx.arc(s.x,s.y,s.r,0,Math.PI*2);
    cx.fillStyle=`rgba(245,242,236,${s.a})`; cx.fill(); });
  requestAnimationFrame(loop); })();

// Horizontal scroll
const track = document.getElementById('htrack16');
const hint = document.getElementById('sh16');
const dots = document.querySelectorAll('.dn16');
let current = 0, panels = 4, isScrolling = false;
const isMobile = () => window.innerWidth <= 900;

function goTo(n) {
  if (isMobile()) return;
  current = Math.max(0, Math.min(panels - 1, n));
  track.style.transform = `translateX(-${current * 100}vw)`;
  dots.forEach((d, i) => d.classList.toggle('active', i === current));
  if (current > 0) hint.classList.add('hidden');
  // Trigger reveals in current panel
  setTimeout(triggerReveals, 200);
}

// Wheel
let wheelTimeout;
window.addEventListener('wheel', e => {
  if (isMobile()) return;
  e.preventDefault();
  if (isScrolling) return;
  isScrolling = true;
  goTo(current + (e.deltaY > 0 ? 1 : -1));
  wheelTimeout = setTimeout(() => isScrolling = false, 900);
}, { passive: false });

// Touch/drag
let touchStartX = 0, isDragging = false;
window.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
window.addEventListener('touchend', e => {
  if (isMobile()) return;
  const dx = e.changedTouches[0].clientX - touchStartX;
  if (Math.abs(dx) > 50) goTo(current + (dx < 0 ? 1 : -1));
}, { passive: true });

// Keyboard
document.addEventListener('keydown', e => {
  if (isMobile()) return;
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); goTo(current + 1); }
  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); goTo(current - 1); }
});

// Dot nav
dots.forEach(d => d.addEventListener('click', () => goTo(+d.dataset.panel)));

// Anchor nav
document.querySelectorAll('a[href^="#panel-"]').forEach(a => {
  a.addEventListener('click', e => {
    if (isMobile()) return;
    e.preventDefault();
    const n = +a.getAttribute('href').split('-')[1] - 1;
    goTo(n);
  });
});

// Form anchor
document.querySelector('a[href="#panel-4"]')?.addEventListener('click', e => {
  if (isMobile()) return; e.preventDefault(); goTo(3);
});

// Reveals
function triggerReveals() {
  const panelEl = document.querySelectorAll('.panel16')[current];
  if (!panelEl) return;
  panelEl.querySelectorAll('.reveal16:not(.visible)').forEach(el => {
    const d = +(el.dataset.d || 0);
    setTimeout(() => el.classList.add('visible'), d);
  });
}
// Trigger panel 1 immediately
setTimeout(triggerReveals, 400);

// Mobile — use IntersectionObserver for reveals
const obs = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const d = +(e.target.dataset.d || 0);
  setTimeout(() => e.target.classList.add('visible'), d);
  obs.unobserve(e.target);
}), { threshold: 0.15 });
document.querySelectorAll('.reveal16').forEach(el => obs.observe(el));

// Form
const form = document.getElementById('form16'), suc = document.getElementById('suc16');
if (form) form.addEventListener('submit', e => {
  e.preventDefault();
  const v = ['f16n','f16b','f16e','f16i'].map(id => document.getElementById(id));
  if (v.some(i => !i.value.trim())) {
    const b = form.querySelector('button'); b.textContent = 'Fill all fields';
    setTimeout(() => b.textContent = 'Request Access', 1600); return;
  }
  const b = form.querySelector('button'); b.textContent = 'Sending…';
  setTimeout(() => { form.style.display = 'none'; suc.classList.add('show'); }, 900);
});
